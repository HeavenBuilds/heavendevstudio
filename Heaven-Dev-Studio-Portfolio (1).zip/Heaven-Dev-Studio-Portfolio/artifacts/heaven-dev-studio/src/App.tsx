import { useState } from 'react';
import { ArrowDown, ArrowDownRight, ArrowRight, ArrowUpRight, Asterisk, Check, Code2, Layers3, Menu, MousePointer2, Send, X } from 'lucide-react';
import { Route, Switch, Router as WouterRouter } from 'wouter';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();
const navItems = [
  ['About me', '#about'],
  ['Portfolio', '#portfolio'],
  ['Services', '#services'],
  ['Contact', '#contact'],
];
const services = [
  { n: '01', title: 'Web applications', body: 'Thoughtful interfaces with the sturdy engineering behind them. From first sketch to a finished, responsive product.', icon: Code2 },
  { n: '02', title: 'Automation tools', body: 'Less repetitive work, fewer loose ends. Purpose-built tools that give good ideas room to move.', icon: Asterisk },
  { n: '03', title: 'Digital experiences', body: 'Distinctive websites and digital experiences with a clear point of view and a little bit of wonder.', icon: Layers3 },
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  const copyIntro = async () => {
    await navigator.clipboard?.writeText("Hi, I'm Heaven' Williams, founder of Heaven Dev Studio. I'm a developer focused on building web applications, automation tools, and creative digital experiences.");
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1800);
  };

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Switch>
            <Route path="/">
              <ErrorBoundary>
                <main className="grain overflow-hidden text-[#12243d]">
                  <header className="fixed inset-x-0 top-0 z-40 border-b border-[#183451]/10 bg-[#edf4f8]/90 backdrop-blur-xl">
                    <div className="mx-auto flex h-[76px] max-w-[1380px] items-center justify-between px-5 md:px-10">
                      <a href="#home" className="group flex items-center gap-3" aria-label="Heaven Dev Studio home">
                        <img src="/heaven-dev-studio-logo.png" alt="Heaven Dev Studio" className="h-11 w-11 rounded-full object-cover object-center" />
                        <span className="text-[12px] font-extrabold leading-[1.1] tracking-[.12em]">HEAVEN<br /><span className="text-[#478fb9]">DEV STUDIO</span></span>
                      </a>
                      <nav className="hidden items-center gap-9 md:flex" aria-label="Main navigation">
                        {navItems.map(([label, href]) => <a key={href} className="text-[12px] font-bold text-[#52667a] transition hover:text-[#0878bc]" href={href}>{label}</a>)}
                      </nav>
                      <a href="#contact" className="hidden items-center gap-2 rounded-full bg-[#12304c] px-5 py-3 text-[11px] font-extrabold uppercase tracking-[.1em] text-white transition hover:bg-[#0878bc] md:flex">Let’s talk <ArrowUpRight size={14} /></a>
                      <button onClick={() => setMenuOpen(!menuOpen)} className="grid h-10 w-10 place-items-center rounded-full border border-[#183451]/15 md:hidden" aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}>{menuOpen ? <X size={19} /> : <Menu size={19} />}</button>
                    </div>
                    {menuOpen && <nav className="border-t border-[#183451]/10 bg-[#edf4f8] px-5 py-4 md:hidden">{navItems.map(([label, href]) => <a key={href} onClick={() => setMenuOpen(false)} className="block border-b border-[#183451]/10 py-3 text-sm font-bold" href={href}>{label}</a>)}</nav>}
                  </header>

                  <section id="home" className="relative min-h-[760px] overflow-hidden px-5 pb-20 pt-32 md:min-h-[820px] md:px-10 md:pt-36">
                    <div className="absolute -right-36 top-24 h-[620px] w-[620px] rounded-full border border-[#1b77ab]/10 md:right-[-8%] md:top-16" />
                    <div className="absolute -right-20 top-40 h-[460px] w-[460px] rounded-full border border-[#1b77ab]/15" />
                    <div className="absolute right-[15%] top-48 h-3 w-3 rounded-full bg-[#f0bf45] shadow-[0_0_0_7px_rgba(240,191,69,.13)]" />
                    <div className="mx-auto grid max-w-[1280px] items-center gap-10 md:grid-cols-[1.1fr_.9fr]">
                      <div className="relative z-10">
                        <div className="reveal mb-7 flex items-center gap-3"><span className="h-px w-10 bg-[#e8b844]" /><span className="font-mono text-[10px] uppercase tracking-[.24em] text-[#54718a]">Independent digital studio</span></div>
                        <h1 className="reveal reveal-delay max-w-[740px] text-[clamp(3.6rem,8.1vw,7.8rem)] font-extrabold leading-[.91] tracking-[-.075em]">Ideas built<br />to <span className="font-serif font-medium italic text-[#1884bb]">take flight.</span></h1>
                        <p className="mt-8 max-w-[510px] text-lg leading-8 text-[#52667a] md:text-[19px]">Building websites, software, and digital solutions.</p>
                        <div className="mt-9 flex flex-wrap items-center gap-4">
                          <a href="#portfolio" className="group inline-flex items-center gap-3 rounded-full bg-[#12304c] px-6 py-4 text-[12px] font-extrabold text-white transition hover:bg-[#0878bc]">Explore the studio <ArrowDownRight size={16} className="transition group-hover:translate-x-1 group-hover:translate-y-1" /></a>
                          <span className="font-mono text-[10px] uppercase tracking-[.12em] text-[#70859a]">Web / Software / Creative</span>
                        </div>
                        <div className="mt-16 flex items-center gap-3 text-[10px] font-mono uppercase tracking-[.16em] text-[#6d8297]"><span className="grid h-8 w-8 place-items-center rounded-full border border-[#193e5d]/20"><ArrowDown size={13} /></span>Scroll to explore</div>
                      </div>
                      <div className="relative mx-auto flex h-[420px] w-full max-w-[520px] items-center justify-center md:h-[520px]">
                        <div className="absolute h-[370px] w-[370px] rounded-full bg-[radial-gradient(circle,rgba(110,190,222,.35),rgba(189,220,235,.08)_58%,transparent_70%)] md:h-[480px] md:w-[480px]" />
                        <div className="orbit absolute h-[380px] w-[380px] rounded-full border border-dashed border-[#1382b5]/25 md:h-[485px] md:w-[485px]" />
                        <div className="absolute h-[280px] w-[280px] rounded-full border border-[#e0b74f]/55 md:h-[340px] md:w-[340px]" />
                        <div className="absolute right-[7%] top-[21%] h-2 w-2 rounded-full bg-[#edbd4a]" />
                        <div className="absolute bottom-[20%] left-[8%] h-1.5 w-1.5 rounded-full bg-[#288fbd]" />
                        <img src="/heaven-dev-studio-logo.png" alt="Heaven Dev Studio logo: a halo above a city of clouds, with a laptop and phone" className="relative z-10 w-[min(92%,430px)] rounded-[28px] drop-shadow-[0_24px_36px_rgba(16,44,72,.23)]" />
                        <div className="absolute bottom-[5%] right-[3%] z-20 rounded-xl border border-white/80 bg-white/70 px-4 py-3 shadow-[0_12px_30px_rgba(32,72,103,.1)] backdrop-blur-sm">
                          <span className="block font-mono text-[9px] uppercase tracking-[.19em] text-[#62809a]">Studio principle</span><span className="mt-1 block text-xs font-extrabold">Build with purpose.</span>
                        </div>
                      </div>
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#183451]/15 to-transparent" />
                  </section>

                  <section id="about" className="px-5 py-24 md:px-10 md:py-32">
                    <div className="mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[.6fr_1.4fr]">
                      <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#1681b2]">01 / The person behind the pixels</p><div className="mt-7 h-px w-16 bg-[#e4b944]" /></div>
                      <div>
                        <h2 className="max-w-[820px] text-[clamp(2.1rem,4.5vw,4.1rem)] font-bold leading-[1.14] tracking-[-.055em]">Hi, I’m Heaven' Williams, <span className="font-serif font-medium italic text-[#1783b8]">founder of Heaven Dev Studio.</span></h2>
                        <div className="mt-8 grid gap-8 md:grid-cols-[1fr_.7fr]">
                          <p className="max-w-[620px] text-[15px] leading-8 text-[#52667a]">I'm a developer focused on building web applications, automation tools, and creative digital experiences.</p>
                          <div className="flex gap-3 border-l border-[#e2b947] pl-5">
                            <MousePointer2 className="mt-1 shrink-0 text-[#1681b2]" size={18} />
                            <p className="text-sm leading-6 text-[#52667a]">A small studio for useful ideas, carefully made and built to work in the real world.</p>
                          </div>
                        </div>
                        <div className="mt-12 grid grid-cols-3 border-y border-[#183451]/15 py-6">
                          <div><p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#70859a]">Focus</p><p className="mt-2 text-sm font-extrabold">Digital craft</p></div>
                          <div><p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#70859a]">Approach</p><p className="mt-2 text-sm font-extrabold">Curious & considered</p></div>
                          <div><p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#70859a]">Studio</p><p className="mt-2 text-sm font-extrabold">Heaven Dev Studio</p></div>
                        </div>
                      </div>
                    </div>
                  </section>

                  <section id="portfolio" className="relative bg-[#12304c] px-5 py-24 text-[#eff7fa] md:px-10 md:py-32">
                    <div className="absolute right-0 top-0 h-full w-[32%] bg-[radial-gradient(ellipse_at_top_right,rgba(24,132,187,.23),transparent_65%)]" />
                    <div className="relative mx-auto max-w-[1180px]">
                      <div className="flex flex-wrap items-end justify-between gap-8">
                        <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#7ac4e2]">02 / Portfolio</p><h2 className="mt-5 text-[clamp(2.7rem,6vw,5.6rem)] font-extrabold leading-[.98] tracking-[-.065em]">Good work<br /><span className="font-serif font-medium italic text-[#efc44f]">takes time.</span></h2></div>
                        <p className="max-w-[330px] pb-2 text-sm leading-7 text-[#b5c9d7]">This studio site is the first project in the portfolio, bringing a developer profile and the studio’s services together.</p>
                      </div>
                      <article className="mt-14 overflow-hidden rounded-[24px] border border-white/15 bg-[#193b59]">
                        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 px-6 py-5 md:px-9">
                          <div className="flex items-center gap-3"><span className="h-2 w-2 rounded-full bg-[#edbf49]" /><span className="font-mono text-[10px] uppercase tracking-[.18em] text-[#b5c9d7]">Project 01 / Studio website</span></div>
                          <span className="font-mono text-[10px] text-[#84a3b8]">PORTFOLIO / FEATURED</span>
                        </div>
                        <div className="grid min-h-[255px] items-center gap-8 p-7 md:grid-cols-[1fr_auto] md:px-9">
                          <div>
                            <h3 className="font-serif text-3xl italic text-[#f0c34c]">Heaven Dev Studio</h3>
                            <p className="mt-4 max-w-[620px] text-sm leading-7 text-[#bfd0da]">A studio website and personal developer portfolio for Heaven' Williams, bringing together web applications, automation tools, creative digital experiences, and future project work.</p>
                            <div className="mt-7 flex flex-wrap gap-3">
                              <a href="#home" data-testid="link-project-one-site" className="inline-flex items-center gap-2 rounded-full bg-[#eff7fa] px-5 py-3 text-[11px] font-extrabold text-[#12304c] transition hover:bg-white">Explore this site <ArrowUpRight size={14} /></a>
                              <a href="https://github.com/HeavenBuilds" target="_blank" rel="noreferrer" data-testid="link-project-one-github" className="inline-flex items-center gap-2 rounded-full border border-white/20 px-5 py-3 text-[11px] font-extrabold text-[#eff7fa] transition hover:border-[#7ac4e2] hover:text-[#7ac4e2]">GitHub profile <ArrowUpRight size={14} /></a>
                            </div>
                          </div>
                          <div className="relative grid h-36 w-36 place-items-center rounded-full border border-dashed border-[#eac14d]/45 text-[#eac14d]"><span className="absolute h-24 w-24 rounded-full border border-[#eac14d]/20" /><Asterisk size={42} strokeWidth={1} /><span className="absolute -bottom-3 rounded-full bg-[#193b59] px-3 font-mono text-[9px] uppercase tracking-[.16em]">Project 01</span></div>
                        </div>
                      </article>
                    </div>
                  </section>

                  <section id="projects" className="px-5 py-24 md:px-10 md:py-28">
                    <div className="mx-auto grid max-w-[1180px] gap-10 md:grid-cols-[.7fr_1.3fr]">
                      <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#1681b2]">03 / Projects & process</p><h2 className="mt-5 text-4xl font-extrabold leading-[1.05] tracking-[-.055em] md:text-5xl">Ideas are only<br />the beginning.</h2></div>
                      <div className="border-t border-[#183451]/15">
                        {[
                          ['01', 'Listen closely', 'Understand the people, the problem, and what a useful outcome actually looks like.'],
                          ['02', 'Make it make sense', 'Shape the idea into a clear experience, with care for every screen and interaction.'],
                          ['03', 'Build for the next step', 'Deliver something considered, dependable, and ready to grow beyond the first release.'],
                        ].map(([n, title, body]) => <div key={n} className="grid gap-4 border-b border-[#183451]/15 py-6 md:grid-cols-[54px_1fr_1.2fr] md:items-baseline"><span className="font-mono text-[10px] text-[#1681b2]">{n}</span><h3 className="font-extrabold">{title}</h3><p className="text-sm leading-6 text-[#61758a]">{body}</p></div>)}
                      </div>
                    </div>
                  </section>

                  <section id="services" className="bg-[#dceaf1] px-5 py-24 md:px-10 md:py-32">
                    <div className="mx-auto max-w-[1180px]">
                      <div className="flex flex-wrap items-end justify-between gap-6">
                        <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#1681b2]">04 / Services</p><h2 className="mt-5 text-[clamp(2.7rem,6vw,5.4rem)] font-extrabold leading-[.96] tracking-[-.065em]">Small studio.<br /><span className="font-serif font-medium italic text-[#1783b8]">Big possibility.</span></h2></div>
                        <p className="max-w-[300px] pb-1 text-sm leading-7 text-[#61758a]">A focused set of ways to turn promising ideas into useful digital things.</p>
                      </div>
                      <div className="mt-14 border-t border-[#183451]/20">
                        {services.map(({ n, title, body, icon: Icon }) => <article key={n} className="group grid gap-4 border-b border-[#183451]/20 py-7 transition md:grid-cols-[70px_1fr_1fr_44px] md:items-center md:py-9">
                          <span className="font-mono text-[10px] text-[#1681b2]">{n}</span><h3 className="text-xl font-extrabold tracking-[-.03em] md:text-2xl">{title}</h3><p className="max-w-[430px] text-sm leading-6 text-[#5c7185]">{body}</p><span className="grid h-10 w-10 place-items-center rounded-full border border-[#183451]/20 text-[#1681b2] transition group-hover:border-[#1681b2] group-hover:bg-[#1681b2] group-hover:text-white"><Icon size={17} /></span>
                        </article>)}
                      </div>
                    </div>
                  </section>

                  <section id="contact" className="relative overflow-hidden px-5 py-24 md:px-10 md:py-32">
                    <div className="absolute -right-16 -top-24 h-[460px] w-[460px] rounded-full border border-[#1783b8]/10" /><div className="absolute -right-2 -top-8 h-[330px] w-[330px] rounded-full border border-[#1783b8]/10" />
                    <div className="relative mx-auto grid max-w-[1180px] gap-12 md:grid-cols-[1fr_.7fr]">
                      <div><p className="font-mono text-[10px] uppercase tracking-[.2em] text-[#1681b2]">05 / Contact</p><h2 className="mt-6 max-w-[700px] text-[clamp(3.3rem,8vw,7rem)] font-extrabold leading-[.9] tracking-[-.075em]">Have a good<br /><span className="font-serif font-medium italic text-[#1783b8]">idea?</span></h2><p className="mt-7 max-w-[430px] text-base leading-7 text-[#5e7285]">Have a project in mind? Heaven Dev Studio is open to conversations about thoughtful web, software, and digital work.</p></div>
                      <div className="flex flex-col justify-end md:pb-2">
                        <p className="mb-4 font-mono text-[10px] uppercase tracking-[.17em] text-[#72879a]">A note from the studio</p>
                        <div className="rounded-2xl border border-[#183451]/15 bg-white/45 p-6 backdrop-blur-sm">
                          <p className="text-sm leading-7 text-[#52667a]">To start a conversation, send a short outline of what you’re hoping to make.</p>
                          <div className="mt-5 flex flex-col items-start gap-3">
                            <a href="mailto:contact@heavenwilliams.me" data-testid="link-contact-email" className="inline-flex items-center gap-2 text-sm font-extrabold text-[#12304c] underline decoration-[#e2b947] decoration-2 underline-offset-4 transition hover:text-[#0878bc]">contact@heavenwilliams.me <ArrowUpRight size={14} /></a>
                            <a href="https://github.com/HeavenBuilds" target="_blank" rel="noreferrer" data-testid="link-contact-github" className="inline-flex items-center gap-2 text-sm font-extrabold text-[#12304c] transition hover:text-[#0878bc]">GitHub / HeavenBuilds <ArrowUpRight size={14} /></a>
                          </div>
                          <button onClick={copyIntro} data-testid="button-copy-studio-intro" className="mt-6 inline-flex items-center gap-3 rounded-full bg-[#12304c] px-5 py-3.5 text-[11px] font-extrabold uppercase tracking-[.1em] text-white transition hover:bg-[#0878bc]">{copied ? <><Check size={14} /> Copied studio intro</> : <>Copy studio intro <Send size={14} /></>}</button>
                        </div>
                      </div>
                    </div>
                  </section>

                  <footer className="bg-[#12304c] px-5 py-7 text-white md:px-10">
                    <div className="mx-auto flex max-w-[1180px] flex-col justify-between gap-5 sm:flex-row sm:items-center">
                      <a href="#home" className="flex items-center gap-3"><img src="/heaven-dev-studio-logo.png" alt="" className="h-9 w-9 rounded-full object-cover" /><span className="text-[10px] font-extrabold tracking-[.16em]">HEAVEN DEV STUDIO</span></a>
                      <p className="font-mono text-[9px] uppercase tracking-[.14em] text-[#9bb2c3]">Building websites, software, and digital solutions.</p>
                      <a href="#home" className="inline-flex items-center gap-2 font-mono text-[9px] uppercase tracking-[.14em] text-[#c1d2dc] transition hover:text-[#f0c34c]">Back to top <ArrowRight size={13} /></a>
                    </div>
                  </footer>
                </main>
              </ErrorBoundary>
            </Route>
            <Route component={NotFound} />
          </Switch>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
