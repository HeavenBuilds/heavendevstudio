import type { ReactNode } from 'react';

type SlideFrameProps = {
  page: string;
  children: ReactNode;
};

export function SlideFrame({ page, children }: SlideFrameProps) {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-bg text-text">
      <div className="absolute left-[5vw] top-[4.5vh] z-20 flex items-center gap-[0.8vw]">
        <span className="h-[0.45vw] w-[0.45vw] rounded-full bg-accent" />
        <span className="font-body text-[1.5vw] font-medium uppercase tracking-[0.1em]">
          Heaven Dev Studio
        </span>
      </div>
      <p className="absolute right-[5vw] top-[4.5vh] z-20 font-body text-[1.5vw] uppercase tracking-[0.1em] text-muted">
        Portfolio Project 01
      </p>
      {children}
      <div className="absolute bottom-[10vh] left-0 h-px w-full bg-white/20" />
      <p className="absolute bottom-[4vh] left-[5vw] font-body text-[1.5vw] text-muted">
        Heaven Dev Studio / Studio and portfolio overview
      </p>
      <p className="absolute bottom-[4vh] right-[5vw] font-body text-[1.5vw] text-muted">
        {page} / 15
      </p>
    </div>
  );
}
