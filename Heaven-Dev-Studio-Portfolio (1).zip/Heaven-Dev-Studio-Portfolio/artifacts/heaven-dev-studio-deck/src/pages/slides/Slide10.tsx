import { SlideFrame } from '../components/SlideFrame';

export default function Slide10() {
  return (
    <SlideFrame page="10">
      <main className="absolute inset-x-[6vw] top-[16vh] bottom-[16vh] flex flex-col justify-center">
        <h1 className="font-display text-[5.5vw] font-normal italic leading-[1.02] text-primary">
          The website at a glance
        </h1>
        <div className="mt-[3vh] border-t border-white/25">
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Home — Introduces the studio and its promise.
          </p>
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            About Me — Introduces Heaven&apos; Williams and the developer focus.
          </p>
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Portfolio — Features the studio website as Project 01.
          </p>
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Projects &amp; Process — Shows the three-step approach.
          </p>
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Services — Presents web applications, automation tools, and digital experiences.
          </p>
          <p className="border-b border-white/20 py-[1.4vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Contact — Connects visitors through email and GitHub.
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
