import { SlideFrame } from '../components/SlideFrame';

export default function Slide03() {
  return (
    <SlideFrame page="03">
      <main className="absolute inset-x-[6vw] top-[18vh] bottom-[16vh] grid grid-cols-[0.75fr_1.25fr] items-center gap-[5vw]">
        <h1 className="font-display text-[5.8vw] font-normal italic leading-[1.02] text-primary">
          Meet the founder
        </h1>
        <div className="border-l border-accent pl-[3vw]">
          <p className="font-body text-[2.7vw] font-light leading-[1.38] text-text">
            Hi, I&apos;m Heaven&apos; Williams, founder of Heaven Dev Studio. I&apos;m a developer focused on building web applications, automation tools, and creative digital experiences.
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
