import { SlideFrame } from '../components/SlideFrame';

const base = import.meta.env.BASE_URL;

export default function Slide12() {
  return (
    <SlideFrame page="12">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] grid grid-cols-[0.82fr_1.18fr] items-center gap-[4vw]">
        <div className="flex flex-col gap-[2.8vh]">
          <h1 className="mb-[1vh] font-display text-[5vw] font-normal italic leading-[1.05] text-primary">
            A visual identity built to stand out
          </h1>
          <p className="border-t border-white/25 pt-[1.8vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            A halo, clouds, wings, and a city skyline
          </p>
          <p className="border-t border-white/25 pt-[1.8vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            A laptop and phone with a code symbol
          </p>
          <p className="border-t border-white/25 pt-[1.8vh] font-body text-[2vw] font-light leading-[1.25] text-text">
            Blue, white, and gold
          </p>
        </div>
        <div className="flex items-center justify-center gap-[1.5vw]">
          <img
            src={`${base}media/heaven-dev-studio-full-lockup.png`}
            crossOrigin="anonymous"
            alt="Heaven Dev Studio logo with the tagline Web Development and App Building"
            className="w-[22vw] object-contain"
          />
          <img
            src={`${base}media/heaven-dev-studio-mark.png`}
            crossOrigin="anonymous"
            alt="Heaven Dev Studio logo with a halo, wings, city, laptop, and phone"
            className="w-[22vw] object-contain"
          />
        </div>
      </main>
    </SlideFrame>
  );
}
