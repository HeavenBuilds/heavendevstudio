import { SlideFrame } from '../components/SlideFrame';

export default function Slide02() {
  return (
    <SlideFrame page="02">
      <main className="absolute inset-x-[6vw] top-[17vh] bottom-[16vh] flex flex-col justify-center">
        <h1 className="max-w-[78vw] font-display text-[5.8vw] font-normal italic leading-[1.04] text-primary">
          One studio. One personal portfolio.
        </h1>
        <div className="mt-[6vh] grid grid-cols-3 gap-[3vw]">
          <p className="border-t border-white/25 pt-[2.5vh] font-body text-[2.35vw] font-light leading-[1.3] text-text">
            Build the Heaven Dev Studio brand
          </p>
          <p className="border-t border-white/25 pt-[2.5vh] font-body text-[2.35vw] font-light leading-[1.3] text-text">
            Introduce Heaven&apos; Williams as the founder and developer
          </p>
          <p className="border-t border-white/25 pt-[2.5vh] font-body text-[2.35vw] font-light leading-[1.3] text-text">
            Bring studio services and personal work together in one site
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
