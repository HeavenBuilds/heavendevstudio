import { SlideFrame } from '../components/SlideFrame';

export default function Slide05() {
  return (
    <SlideFrame page="05">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] flex flex-col justify-center">
        <h1 className="font-display text-[5.8vw] font-normal italic leading-[1.02] text-primary">
          Three areas of focus
        </h1>
        <div className="mt-[5vh] grid flex-1 grid-cols-3 gap-[1.5vw]">
          <div className="flex items-end bg-blue p-[2.5vw]">
            <p className="font-body text-[2.8vw] font-semibold leading-[1.1] text-white">
              Web applications
            </p>
          </div>
          <div className="flex items-end bg-accent p-[2.5vw]">
            <p className="font-body text-[2.8vw] font-semibold leading-[1.1] text-[#181612]">
              Automation tools
            </p>
          </div>
          <div className="flex items-end bg-deep-blue p-[2.5vw]">
            <p className="font-body text-[2.8vw] font-semibold leading-[1.1] text-white">
              Creative digital experiences
            </p>
          </div>
        </div>
      </main>
    </SlideFrame>
  );
}
