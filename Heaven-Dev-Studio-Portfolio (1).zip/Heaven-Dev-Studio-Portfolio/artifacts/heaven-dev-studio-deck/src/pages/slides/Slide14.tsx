import { SlideFrame } from '../components/SlideFrame';

export default function Slide14() {
  return (
    <SlideFrame page="14">
      <main className="absolute inset-x-[6vw] top-[16vh] bottom-[16vh] grid grid-cols-[0.9fr_1.1fr] items-center gap-[5vw]">
        <h1 className="font-display text-[6.2vw] font-normal italic leading-[1.02] text-primary">
          Start a conversation
        </h1>
        <div className="flex flex-col gap-[3vh] border-l border-accent pl-[4vw]">
          <a
            href="mailto:contact@heavenwilliams.me"
            className="inline-flex items-center gap-[1vw] font-body text-[2.5vw] font-medium text-text"
          >
            Email: contact@heavenwilliams.me <span aria-hidden="true">↗</span>
          </a>
          <a
            href="https://github.com/HeavenBuilds"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-[1vw] font-body text-[2.5vw] font-medium text-text"
          >
            GitHub: github.com/HeavenBuilds <span aria-hidden="true">↗</span>
          </a>
          <p className="max-w-[42vw] border-t border-white/25 pt-[2.5vh] font-body text-[2vw] font-light leading-[1.35] text-muted">
            Conversations about thoughtful web, software, and digital work
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
