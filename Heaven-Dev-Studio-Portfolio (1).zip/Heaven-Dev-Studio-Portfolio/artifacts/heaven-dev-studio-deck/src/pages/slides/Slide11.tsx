import { SlideFrame } from '../components/SlideFrame';

const base = import.meta.env.BASE_URL;

export default function Slide11() {
  return (
    <SlideFrame page="11">
      <main className="absolute inset-x-[5vw] top-[15vh] bottom-[15vh] flex flex-col justify-center">
        <h1 className="font-display text-[5.2vw] font-normal italic leading-[1.02] text-primary">
          Project 01 — Heaven Dev Studio
        </h1>
        <div className="mt-[2.5vh] grid grid-cols-2 gap-[2vw]">
          <img
            src={`${base}media/heaven-dev-studio-home.jpg`}
            crossOrigin="anonymous"
            alt="Screenshot of the Heaven Dev Studio home section"
            className="h-[25vh] w-full object-cover object-top"
          />
          <img
            src={`${base}media/heaven-dev-studio-portfolio.jpg`}
            crossOrigin="anonymous"
            alt="Screenshot of the Heaven Dev Studio Project 01 portfolio section"
            className="h-[25vh] w-full object-cover object-center"
          />
        </div>
        <div className="mt-[3vh] grid grid-cols-3 gap-[2vw]">
          <p className="border-t border-white/25 pt-[1.7vh] font-body text-[2vw] font-light leading-[1.3] text-text">
            Project: the Heaven Dev Studio website and developer portfolio
          </p>
          <p className="border-t border-white/25 pt-[1.7vh] font-body text-[2vw] font-light leading-[1.3] text-text">
            Purpose: bring the studio brand and personal developer portfolio together
          </p>
          <p className="border-t border-white/25 pt-[1.7vh] font-body text-[2vw] font-light leading-[1.3] text-text">
            Portfolio position: the first featured project
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
