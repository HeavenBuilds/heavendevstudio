import { SlideFrame } from '../components/SlideFrame';

export default function Slide07() {
  return (
    <SlideFrame page="07">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] grid grid-cols-[0.9fr_1.1fr]">
        <div className="flex flex-col justify-center bg-accent px-[3.5vw] py-[4vh]">
          <h1 className="font-display text-[5.5vw] font-normal italic leading-[1.05] text-[#181612]">
            Automation tools
          </h1>
        </div>
        <div className="flex items-center px-[4vw]">
          <p className="font-body text-[2.4vw] font-light leading-[1.42] text-text">
            Less repetitive work, fewer loose ends. Purpose-built tools that give good ideas room to move.
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
