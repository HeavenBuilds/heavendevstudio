import { SlideFrame } from '../components/SlideFrame';

const base = import.meta.env.BASE_URL;

export default function Slide01() {
  return (
    <SlideFrame page="01">
      <main className="absolute inset-x-[5vw] top-[14vh] bottom-[15vh] flex flex-col items-center justify-center text-center">
        <img
          src={`${base}media/heaven-dev-studio-mark.png`}
          crossOrigin="anonymous"
          alt="Heaven Dev Studio logo with a halo, wings, city, laptop, and phone"
          className="h-[22vh] w-[22vh] object-contain"
        />
        <h1 className="mt-[1.5vh] font-display text-[7.4vw] font-normal italic leading-[0.98] text-primary">
          Heaven Dev Studio
        </h1>
        <p className="mt-[2vh] max-w-[68vw] font-body text-[2vw] font-light leading-[1.35] text-muted">
          Building websites, software, and digital solutions.
        </p>
        <p className="mt-[1vh] font-body text-[1.5vw] font-light text-muted">
          Studio and portfolio overview
        </p>
      </main>
    </SlideFrame>
  );
}
