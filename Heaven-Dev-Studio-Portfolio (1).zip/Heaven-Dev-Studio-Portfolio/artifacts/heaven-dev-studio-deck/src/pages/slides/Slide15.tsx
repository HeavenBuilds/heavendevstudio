import { SlideFrame } from '../components/SlideFrame';

const base = import.meta.env.BASE_URL;

export default function Slide15() {
  return (
    <SlideFrame page="15">
      <main className="absolute inset-x-[5vw] top-[14vh] bottom-[15vh] flex flex-col items-center justify-center text-center">
        <img
          src={`${base}media/heaven-dev-studio-full-lockup.png`}
          crossOrigin="anonymous"
          alt="Heaven Dev Studio logo with the tagline Web Development and App Building"
          className="h-[24vh] w-[24vh] object-contain"
        />
        <h1 className="mt-[2vh] max-w-[86vw] font-display text-[6.8vw] font-normal italic leading-[1.02] text-primary">
          Ideas built to take flight.
        </h1>
        <p className="mt-[2.5vh] font-body text-[2.2vw] font-medium text-text">
          Heaven Dev Studio
        </p>
        <p className="mt-[1vh] max-w-[66vw] font-body text-[2vw] font-light leading-[1.35] text-muted">
          Building websites, software, and digital solutions.
        </p>
      </main>
    </SlideFrame>
  );
}
