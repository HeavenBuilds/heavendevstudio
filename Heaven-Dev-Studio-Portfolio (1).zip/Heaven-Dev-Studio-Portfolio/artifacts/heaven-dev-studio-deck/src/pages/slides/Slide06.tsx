import { SlideFrame } from '../components/SlideFrame';

export default function Slide06() {
  return (
    <SlideFrame page="06">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] grid grid-cols-[1.05fr_0.95fr]">
        <div className="flex items-center bg-blue px-[4vw] py-[4vh]">
          <h1 className="font-display text-[6vw] font-normal italic leading-[1.02] text-white">
            Web applications
          </h1>
        </div>
        <div className="flex items-center px-[4vw]">
          <p className="font-body text-[2.4vw] font-light leading-[1.42] text-text">
            Thoughtful interfaces with the sturdy engineering behind them. From first sketch to a finished, responsive product.
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
