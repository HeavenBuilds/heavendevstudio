import { SlideFrame } from '../components/SlideFrame';

export default function Slide09() {
  return (
    <SlideFrame page="09">
      <main className="absolute inset-x-[6vw] top-[16vh] bottom-[16vh] flex flex-col justify-center">
        <h1 className="font-display text-[5.7vw] font-normal italic leading-[1.02] text-primary">
          From idea to next step
        </h1>
        <div className="mt-[3vh] border-t border-white/25">
          <div className="grid grid-cols-[0.72fr_1.28fr] items-center gap-[3vw] border-b border-white/20 py-[2.2vh]">
            <h2 className="font-display text-[2.6vw] font-normal italic text-accent">
              Listen closely
            </h2>
            <p className="font-body text-[2vw] font-light leading-[1.3] text-text">
              Understand the people, the problem, and what a useful outcome looks like.
            </p>
          </div>
          <div className="grid grid-cols-[0.72fr_1.28fr] items-center gap-[3vw] border-b border-white/20 py-[2.2vh]">
            <h2 className="font-display text-[2.6vw] font-normal italic text-accent">
              Make it make sense
            </h2>
            <p className="font-body text-[2vw] font-light leading-[1.3] text-text">
              Shape the idea into a clear experience, with care for every screen and interaction.
            </p>
          </div>
          <div className="grid grid-cols-[0.72fr_1.28fr] items-center gap-[3vw] border-b border-white/20 py-[2.2vh]">
            <h2 className="font-display text-[2.6vw] font-normal italic text-accent">
              Build for the next step
            </h2>
            <p className="font-body text-[2vw] font-light leading-[1.3] text-text">
              Deliver something considered, dependable, and ready to grow beyond the first release.
            </p>
          </div>
        </div>
      </main>
    </SlideFrame>
  );
}
