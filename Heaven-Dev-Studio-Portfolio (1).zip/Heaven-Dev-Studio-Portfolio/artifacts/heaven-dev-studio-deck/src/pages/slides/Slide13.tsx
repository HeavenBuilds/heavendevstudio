import { SlideFrame } from '../components/SlideFrame';

export default function Slide13() {
  return (
    <SlideFrame page="13">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] grid grid-cols-[1.1fr_0.9fr]">
        <div className="flex flex-col justify-center pr-[4vw]">
          <h1 className="font-display text-[5.5vw] font-normal italic leading-[1.05] text-primary">
            A portfolio that grows with the work
          </h1>
        </div>
        <div className="flex flex-col justify-center gap-[3vh] bg-blue px-[3.5vw] py-[4vh]">
          <p className="font-body text-[2.2vw] font-light leading-[1.25] text-white">
            Start with the studio website as Project 01
          </p>
          <p className="border-t border-white/30 pt-[2.5vh] font-body text-[2.2vw] font-light leading-[1.25] text-white">
            Add future client work as projects are ready to share
          </p>
          <p className="border-t border-white/30 pt-[2.5vh] font-body text-[2.2vw] font-light leading-[1.25] text-white">
            Add confirmed technology details and build videos when available
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
