import { SlideFrame } from '../components/SlideFrame';

export default function Slide04() {
  return (
    <SlideFrame page="04">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] grid grid-cols-[1.05fr_0.95fr]">
        <div className="flex flex-col justify-center pr-[4vw]">
          <h1 className="font-display text-[5.6vw] font-normal italic leading-[1.05] text-primary">
            A studio for useful digital ideas
          </h1>
        </div>
        <div className="flex flex-col justify-center gap-[3vh] bg-blue px-[4vw] py-[4vh]">
          <p className="font-body text-[2.3vw] font-medium leading-[1.25] text-white">
            Independent digital studio
          </p>
          <p className="border-t border-white/30 pt-[2.5vh] font-body text-[2.3vw] font-light leading-[1.25] text-white">
            Building websites, software, and digital solutions
          </p>
          <p className="border-t border-white/30 pt-[2.5vh] font-body text-[2.3vw] font-light leading-[1.25] text-white">
            Guided by a simple principle: Build with purpose.
          </p>
        </div>
      </main>
    </SlideFrame>
  );
}
