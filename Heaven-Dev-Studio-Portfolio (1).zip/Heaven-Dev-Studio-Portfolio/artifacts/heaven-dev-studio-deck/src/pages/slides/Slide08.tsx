import { SlideFrame } from '../components/SlideFrame';

export default function Slide08() {
  return (
    <SlideFrame page="08">
      <main className="absolute inset-x-[5vw] top-[16vh] bottom-[16vh] flex flex-col justify-center">
        <div className="max-w-[78vw] bg-deep-blue px-[4vw] py-[5vh]">
          <h1 className="font-display text-[5.5vw] font-normal italic leading-[1.05] text-primary">
            Creative digital experiences
          </h1>
        </div>
        <p className="mt-[4vh] max-w-[68vw] font-body text-[2.4vw] font-light leading-[1.42] text-muted">
          Distinctive websites and digital experiences with a clear point of view and a little bit of wonder.
        </p>
      </main>
    </SlideFrame>
  );
}
